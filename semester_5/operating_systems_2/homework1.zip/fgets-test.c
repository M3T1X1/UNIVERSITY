#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    printf("fgets-test.c\n\n");
    char str[15];

    fgets(str, 15, stdin);
    int string_length = strlen(str);

    printf("bufor = %d",string_length);

    return 0;
}