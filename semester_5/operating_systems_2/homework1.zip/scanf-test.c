#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    printf("scanf-test.c\n\n");

    char str[15];

    scanf("%s", str);
    int string_length = strlen(str);

    printf("bufor = %d",string_length);

    return 0;
}
