#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    printf("stdin-test.c\n\n");

    if (stdin == NULL) {
        printf("\nStdin is empty");
    } else {
        printf("\nStdin is not empty");
    }

    return 0;
}
