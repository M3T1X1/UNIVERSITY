package ex2;

public class Auto {
    String marka;
    String model;
    int rocznik;

    Auto(String marka, String model, int rocznik) {
        this.marka = marka;
        this.model = model;
        this.rocznik = rocznik;
    }

}
