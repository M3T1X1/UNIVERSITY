package ex3;
import java.util.Scanner;

public class ZadaniaD {
    public static void main(String[] args) {
        Scanner skaner = new Scanner(System.in);
        System.out.println("Wybierz figure: \n" +
                "1-kolo\n" +
                "2-kula\n" +
                "3-kwadrat\n" +
                "4-prostokat\n" +
                "5-prostopadloscian\n" +
                "6-stozek\n" +
                "7-szescian\n");

        int liczba = skaner.nextInt();
        if(liczba==1)
        {
            
        }
    }
}
